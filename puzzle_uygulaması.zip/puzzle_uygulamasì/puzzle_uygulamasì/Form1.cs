﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace puzzle_uygulaması
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Bu metotta " ... " butona tıklayarak puzzle uygulamasında kullanmak istediğimiz resmi dosyalarımızdan seçmemizi sağladık.
        /// Textbox kısmında seçtiğimiz resmin dosya ismini yazdırdık.
        /// Resmimizin boyutlarını groupboxın boyutlarına eşitleyerek resmi groupboxın içine yerleştirdik.
        /// </summary>
        OpenFileDialog openFileDialog =null;
        Image image = null;
        PictureBox pictureBox = null;
        private void buttonImageBrowse_Click(object sender, EventArgs e)
        {
            if(openFileDialog == null)
            {
                openFileDialog = new OpenFileDialog();
            }
            if(openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                textBoxImagePath.Text = openFileDialog.FileName;
                image = createBitmapImage(Image.FromFile(openFileDialog.FileName));
                if(pictureBox == null)
                {
                    pictureBox = new PictureBox();
                    pictureBox.Width = groupBoxPuzzle.Width;
                    pictureBox.Height = groupBoxPuzzle.Height;
                    groupBoxPuzzle.Controls.Add(pictureBox);
                }
                pictureBox.Image = image;
            }
            
        }


        /// <summary>
        /// Bu metotta puzzle için seçilen resmin tamamının ekrana gelmesini sağladık.
        /// </summary>
        /// <param name="image"></param>
        /// <param name="ımages"></param>
        /// <param name="index"></param>
        /// <param name="numRow"></param>
        /// <param name="numCol"></param>
        /// <param name="unitX"></param>
        /// <param name="unitY"></param>
        /// <returns></returns>
        private Bitmap createBitmapImage(Image image)
        {
            Bitmap bitmap = new Bitmap(groupBoxPuzzle.Width, groupBoxPuzzle.Height);

            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.Clear(Color.White);
            graphics.DrawImage(image, new Rectangle(0, 0, groupBoxPuzzle.Width, groupBoxPuzzle.Height));
            graphics.Flush();
            
            return bitmap;
        }

       
        /// <summary>
        /// Bu metotta level 1 butonuna tıklandığında seçilen resmi 4 parçaya ayırdık ve playlevel metodunun çalıştırılamsını sağladık.
        /// </summary>
        MyPictureBox[] pictureBoxes = null;
        const int LEVEL_1_NUM = 4;
        Image[] images = null;
        int currentLevel = 0;
        private void buttonLevel1_Click(object sender, EventArgs e)
        {
            currentLevel = LEVEL_1_NUM;
            labelStatus.Text = "Level 1 is onging...";
            playLevel();
        }

        /// <summary>
        /// Bu metotta leveller seçildikten sonra pictureboxı kaldırdık. 
        /// Izgara görünümü için satır, sütun, genişlik ve yükseklik ölçülerini ayarladık.
        /// En sonda ise resmin parçalarının rastgele olarak atanması için izin verdik.
        /// </summary>
        private void playLevel()
        {
            if(pictureBox != null)
            {
                groupBoxPuzzle.Controls.Remove(pictureBox);
                pictureBox.Dispose();
                pictureBox = null;
            }

            if(pictureBoxes == null || pictureBoxes.Length != currentLevel)
            {
                pictureBoxes = new MyPictureBox[currentLevel];
                images=new Image[currentLevel];
            }

            int numRow = (int)Math.Sqrt(currentLevel);
            int numCol = numRow;
            int unitX = groupBoxPuzzle.Width / numRow;
            int unitY = groupBoxPuzzle.Height / numCol;
            int[] indices = new int[currentLevel];
            for(int i = 0 ; i < currentLevel ; i++)
            {
                indices[i] = i;
                if(pictureBoxes[i] == null)
                {
                    pictureBoxes[i] = new MyPictureBox();
                    pictureBoxes[i].Click += new EventHandler(OnPuzzleClick);
                }
                pictureBoxes[i].Width = unitX;
                pictureBoxes[i].Height = unitY;
                ((MyPictureBox)pictureBoxes[i]).Index = i;
                createBitmapImage(image, images, i, numRow, numCol, unitX, unitY);
                pictureBoxes[i].Location = new Point(unitX * (i % numCol), unitY * (i / numCol));
                if (!groupBoxPuzzle.Controls.Contains(pictureBoxes[i]))
                {
                    groupBoxPuzzle.Controls.Add(pictureBoxes[i]);
                }
            }
            shuffle(ref indices);

            for(int i = 0; i < currentLevel ; i++)
            {
                pictureBoxes[i].Image = images[indices[i]];
                pictureBoxes[i].ImageIndex = indices[i];
            }
        }

        /// <summary>
        /// Bu metot önceden oluşturduğumuz createBitmapImage in prototipidir.
        /// Levellere göre seçilen resmin parçalarına indeksler atadık.
        /// </summary>
        /// <param name="image"></param>
        /// <param name="images"></param>
        /// <param name="index"></param>
        /// <param name="numRow"></param>
        /// <param name="numCol"></param>
        /// <param name="unitX"></param>
        /// <param name="unitY"></param>
        private void createBitmapImage(Image image, Image[] images, int index, int numRow, int numCol, int unitX, int unitY)
        {
            images[index] = new Bitmap(unitX, unitY);
            Graphics graphics = Graphics.FromImage(images[index]);
            graphics.Clear(Color.White);

            graphics.DrawImage(image,
                new Rectangle(0, 0, unitX, unitY),
                new Rectangle(unitX * (index % numCol), unitY * (index / numCol), unitX, unitY),
                GraphicsUnit.Pixel);
            graphics.Flush();
        }


        /// <summary>
        /// Bu metotta bölünmüş resim parçalarını rastgele olarak dağıtılmasını sağladık.
        /// </summary>
        /// <param name="array"></param>
        private void shuffle(ref int []array)
        {
            Random random = new Random();
            int n = array.Length;
            while(n > 1)
            {
                int k = random.Next(n);
                n--;
                int temp = array[n];
                array[n] = array[k];
                array[k] = temp;
            }
        }


        /// <summary>
        /// Bu metotta puzzle parçalarına tıklandığında kenarlık özelliklerini değiştirerek parçalara tıkladığımızı kolayca anlayabilmemizi sağladık.
        /// </summary>
        MyPictureBox firstBox;
        MyPictureBox secondBox;
        public void OnPuzzleClick(object sender, EventArgs e)
        {
            if(firstBox == null)
            {
                firstBox = (MyPictureBox)sender;
                firstBox.BorderStyle = BorderStyle.Fixed3D;
            }
            else if(secondBox == null)
            {
                secondBox = (MyPictureBox)sender;
                firstBox.BorderStyle = BorderStyle.FixedSingle;
                secondBox.BorderStyle = BorderStyle.Fixed3D;
                SwitchImage(firstBox, secondBox);
                firstBox = null;
                secondBox = null;
            }
            //else
            //{
            //    firstBox = secondBox;
            //    firstBox.BorderStyle = BorderStyle.FixedSingle;
            //    secondBox = (MyPictureBox)sender;
            //    secondBox.BorderStyle = BorderStyle.Fixed3D;
            //    SwitchImage(firstBox, secondBox);
            //}

            //((MyPictureBox)sender).BorderStyle = BorderStyle.Fixed3D;
        }
        private void SwitchImage(MyPictureBox box1, MyPictureBox box2)
        {
            int tmp = box2.ImageIndex;
            box2.Image = images[box1.ImageIndex];
            box2.ImageIndex = box1.ImageIndex;
            box1.Image = images[tmp];
            box1.ImageIndex = tmp;
            
        }

        
        /// <summary>
        /// Bu metotta level 2 butonuna tıkladığımızda seçilen resmi 9 parçaya ayırdık ve playlevel metodunun çalıştırılamsını sağladık.
        /// </summary>
        private const int LEVEL_2_NUM = 9;
        private void buttonLevel2_Click(object sender, EventArgs e)
        {
            currentLevel = LEVEL_2_NUM;
            labelStatus.Text = "Level 2 is onging...";
            playLevel();
        }


        /// <summary>
        /// Bu metotta level 3 butonuna tıkladığımızda seçilen resmi 16 parçaya ayırdık ve playlevel metodunun çalıştırılamsını sağladık.
        /// </summary>
        private const int LEVEL_3_NUM = 16;
        private void buttonLevel3_Click(object sender, EventArgs e)
        {
            currentLevel = LEVEL_3_NUM;
            labelStatus.Text = "Level 3 is onging...";
            playLevel();
        }


        /// <summary>
        /// Bu metotta level 4 butonuna tıkladığımızda seçilen resmi 25 parçaya ayırdık ve playlevel metodunun çalıştırılamsını sağladık.
        /// </summary>
        private const int LEVEL_4_NUM = 25;
        private void buttonLevel4_Click(object sender, EventArgs e)
        {
            currentLevel = LEVEL_4_NUM;
            labelStatus.Text = "Level 4 is onging...";
            playLevel();
        }
    }
}
